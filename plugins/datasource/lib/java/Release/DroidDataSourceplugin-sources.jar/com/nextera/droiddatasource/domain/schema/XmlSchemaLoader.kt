package com.nextera.droiddatasource.domain.schema

import android.content.Context
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.rightware.kanzi.DataSource
import com.rightware.kanzi.Platform
import org.xml.sax.InputSource
import java.io.IOException
import java.nio.file.Files
import java.nio.file.Paths
import javax.xml.parsers.SAXParserFactory
import kotlin.text.clear

/**
 * 从 XML 文件加载 [SchemaDocument]。
 *
 * 加载路径：
 * - **Kanzi Studio Preview**：`parser.parse(绝对路径)` 读磁盘文件
 * - **Android**：优先读可访问的绝对路径，否则从 `assets` 按 [SaxHandler.fileName] 打开
 *   （`DroidDataSourceClient.filePath(".../dataTest.xml")` 实际按文件名 `dataTest.xml` 读 assets）
 *
 * 解析逻辑见 [SaxHandler]。
 */
class XmlSchemaLoader {
    private val tag = XmlSchemaLoader::class.java.simpleName
    private val saxParser = try {
        SAXParserFactory.newInstance().newSAXParser()
    } catch (e: Exception) {
        PluginLogger.d(tag, "saxParser can't be created. $e")
        null
    }

    fun load(path: String, dataSource: DataSource): SchemaDocument {
        val parser = saxParser ?: throw IllegalStateException("SAX parser unavailable")
        val handler = SaxHandler(path)
        try {
            if (Platform.isAndroid()) {
                val context = dataSource.domain.platformContext as Context
                parseFromAndroid(context, handler, parser)
            } else {
                parser.parse(handler.initPath, handler)
            }
            return handler.toDocument()
        } catch (e: Exception) {
            handler.clear()
            throw RuntimeException("xml can't be loaded. $e")
        } finally {
            parser.reset()
            handler.clear()
        }
    }

    private fun parseFromAndroid(
        context: Context,
        handler: SaxHandler,
        parser: javax.xml.parsers.SAXParser
    ) {
        var inputSource: InputSource? = null
        try {
            inputSource = openInputSource(context, handler)
            parser.parse(inputSource, handler)
        } catch (e: Exception) {
            handler.clear()
            throw RuntimeException("xml can't be loaded. $e")
        } finally {
            try {
                inputSource?.byteStream?.close()
            } catch (e: IOException) {
                PluginLogger.d(tag, "Error for xml stream close. $e")
            }
        }
    }

    private fun openInputSource(context: Context, handler: SaxHandler): InputSource {
        val path = Paths.get(handler.initPath)
        if (Files.isReadable(path) && Files.isWritable(path)) {
            return InputSource(Files.newInputStream(path))
        }
        return InputSource(context.assets.open(handler.fileName))
    }
}