package com.nextera.droiddatasource.domain.binding

import com.nextera.droiddatasource.domain.list.ListStore
import com.nextera.droiddatasource.domain.schema.SchemaDocument
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.nextera.droiddatasource.model.BaseData
import com.nextera.droiddatasource.model.ItemVessel
import com.nextera.droiddatasource.model.TreeNode
import com.rightware.kanzi.DataObject
import com.rightware.kanzi.DataObjectType
import com.rightware.kanzi.Domain
import com.rightware.kanzi.ObjectRef
import kotlin.text.get

/**
 * FileName:     KanziTreeBinder
 * Author:       gan long
 * CreateDate:   2026/6/10-14:09
 * Description: 
 **/

/**
 * 将 [SchemaDocument]（XML 解析结果）绑定为 Kanzi [DataObject] 树。
 *
 * ## 在整体流程中的位置
 *
 * ```
 * XmlSchemaLoader.load()
 *   └─ SchemaDocument { tree, listTemplates }
 *
 * KanziTreeBinder.bind(document, kanziRoot)     ← 本类
 *   ├─ listStore.install(document)              // 把列表列定义写入 ListStore
 *   └─ buildNode(tree, root)                    // 递归创建 Kanzi 节点树
 *
 * 运行时 Android 写列表数据
 *   └─ ListStore.addItems(...)                  // 数据存在 ListStore
 *   └─ ValueController.notifyListModified()     // 通知 Kanzi 刷新
 *
 * Kanzi 渲染列表项时
 *   └─ DroidDataSource.List.acquireItem(index)
 *   └─ ListController → createListItem(vessel)  // 把 ItemVessel 转成 DataObject 子树
 * ```
 *
 * [bind] 只在 `onLoaded` 阶段执行一次，建立**静态结构**（有哪些节点、列表模板长什么样）。
 * 列表**动态数据**（addItems 追加的行）不在 bind 时写入，而是在 Kanzi 按需拉取时通过
 * [createListItem] 即时构建。
 */
class KanziTreeBinder(
    private val listStore: ListStore
) {
    private val tag = KanziTreeBinder::class.java.simpleName
    private val factory = KanziObjectFactory()

    /**
     * 入口：安装列表模板并递归构建整棵 Kanzi 数据树。
     *
     * @param document SAX 解析产物，含 [SchemaDocument.tree] 与 [SchemaDocument.listTemplates]
     * @param root Kanzi DataSource 的根 DataObject（`DroidDataSource.getData()`）
     */
    fun bind(document: SchemaDocument, root: DataObject) {
        listStore.install(document)
        buildNode(document.tree, root)
    }

    /**
     * 把一条列表运行时数据（[ItemVessel]）物化为 Kanzi 可用的 DataObject 子树。
     *
     * 结构示例（`List_Test` 含 `index`、`icon` 两列）：
     *
     * ```
     * Items (容器)
     *   ├─ index  (DataObjectString)
     *   └─ icon   (DataObjectString，值可为 content:// URI)
     * ```
     *
     * Kanzi [com.rightware.kanzi.DataObjectList] 在 `acquireItem(index)` 时拿到这棵树，
     * 绑定到列表项 UI 模板。
     *
     * @param vessel 来自 [ListStore] 的某一行；`null` 时仅返回空容器（用于 itemTemplate）
     */
    fun createListItem(vessel: ItemVessel?, domain: Domain): ObjectRef<DataObject> {
        val container: ObjectRef<DataObject> = DataObject.create(domain, "Items")
        vessel?.columns?.forEach { field ->
            factory.create(domain, field).get()?.let { container.get().addChild(it) }
        }
        return container
    }

    /**
     * 深度优先遍历 [TreeNode]，为每个 [BaseData] 创建对应 Kanzi 节点并挂到父节点下。
     *
     * - 标量节点：直接 [KanziObjectFactory.create]
     * - `type=list` 节点：创建 [com.nextera.droiddatasource.DroidDataSource.List]，其内部列定义已在 [ListStore] 中，
     *   不在树上再挂子节点（XML 里 list 内部的 `<index>`、`<icon>` 只进模板，不进树）
     */
    private fun buildNode(node: TreeNode<BaseData>?, parent: DataObject) {
        if (node == null) return

        val baseData = node.data
        var current = parent
        if (baseData != null) {
            current = if (baseData.type == DataObjectType.List) {
                factory.createList(baseData.name, parent.domain)
            } else {
                factory.create(parent.domain, baseData).get()
            }
            parent.addChild(current)
            PluginLogger.d(tag, "bind node: ${current.name}")
        }

        node.children.forEach { child -> buildNode(child, current) }
    }
}