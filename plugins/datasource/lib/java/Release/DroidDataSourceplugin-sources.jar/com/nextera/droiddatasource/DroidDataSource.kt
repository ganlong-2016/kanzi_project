package com.nextera.droiddatasource

import com.nextera.droiddatasource.api.DroidDataSourceClient
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.rightware.kanzi.DataObject
import com.rightware.kanzi.DataObjectList
import com.rightware.kanzi.DataSource
import com.rightware.kanzi.Domain
import com.rightware.kanzi.EditorInfo
import com.rightware.kanzi.Factory
import com.rightware.kanzi.Metaclass
import com.rightware.kanzi.Metadata
import com.rightware.kanzi.ObjectRef
import com.rightware.kanzi.Platform
import com.rightware.kanzi.PropertyType

/** Kanzi 侧 DataSource 薄适配：生命周期委托给 [DroidDataSourceClient.engine]。 */
class DroidDataSource private constructor(
    domain: Domain,
    handle: Long,
    metaclass: Metaclass
) : DataSource(domain, handle, metaclass){
    private lateinit var root: ObjectRef<DataObject>

    override fun getData(): DataObject = root.get()

    override fun initialize() {
        super.initialize()
        root = DataObject.create(domain, "Root")
        DroidDataSourceClient.engine.start(this)
    }

    override fun onLoaded() {
        super.onLoaded()
        if (!Platform.isAndroid()) {
            DroidDataSourceClient.applyStudioLogging(getProperty(LOG))
        }
        PluginLogger.d("TAG","file path ${getProperty(File)}")
        val path = DroidDataSourceClient.resolveXmlPath(
            androidFileProperty = if (Platform.isAndroid()) getProperty(File) else "",
            studioFileProperty = getProperty(File)
        )
        DroidDataSourceClient.engine.onLoaded(path)
    }

    override fun close() {
        DroidDataSourceClient.engine.stop(this)
        root.close()
        super.close()
    }


    class List private constructor(
        domain: Domain,
        nativeObject: Long,
        metaclass: Metaclass
    ) : DataObjectList(domain, nativeObject, metaclass) {

        private val controller get() = DroidDataSourceClient.engine.activeListController

        override fun initialize() {
            super.initialize()
            controller.onListInitialized(name)
        }

        override fun itemCount(): Int = controller.itemCount(name)

        override fun acquireItem(index: Int): DataObject = controller.acquireItem(name, index)

        override fun releaseItem(index: Int) = controller.onItemReleased(name, index)

        override fun getItemTemplate(): ObjectRef<out DataObject> = controller.itemTemplate(name)

        override fun close() {
            controller.onListClosed(name)
            super.close()
        }

        companion object {
            @JvmField
            @Metadata
            val sStaticMetaclass = Metaclass("DroidDataSource.List")

            @Factory
            @JvmStatic
            fun factoryFunction(domain: Domain, name: String): ObjectRef<List> =
                createDerived(domain, name, sStaticMetaclass)
        }
    }

    companion object {
        @JvmField
        @Metadata
        val metaclass = Metaclass("DroidDataSource")

        @JvmField
        @Metadata
        @EditorInfo(displayName = "File Path (default for xml)", editor = "BrowseFileTextEditor")
        val File = PropertyType<String>("DroidDataSource.File", String::class.java)

        @JvmField
        @Metadata
        @EditorInfo(displayName = "Log Open")
        val LOG = PropertyType<Boolean>("DroidDataSource.Log", Boolean::class.javaObjectType)

        @JvmStatic
        fun create(domain: Domain, name: String): ObjectRef<DroidDataSource> =
            createDerived(domain, name, metaclass)
    }
}