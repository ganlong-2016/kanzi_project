package com.nextera.droiddatasource.model

/**
 * FileName:     TreeNode
 * Author:       gan long
 * CreateDate:   2026/6/5-10:27
 * Description: 
 **/
class TreeNode<T>(val data: T?) {
    var parent: TreeNode<T>? = null
        private set

    private val _children = mutableListOf<TreeNode<T>>()
    val children: List<TreeNode<T>>
        get() = _children

    fun addChild(child: TreeNode<T>) {
        _children.add(child)
        child.parent = this
    }
}