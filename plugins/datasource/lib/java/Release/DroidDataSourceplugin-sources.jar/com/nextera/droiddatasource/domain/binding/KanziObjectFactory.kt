package com.nextera.droiddatasource.domain.binding

import com.nextera.droiddatasource.DroidDataSource
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.nextera.droiddatasource.model.BaseData
import com.rightware.kanzi.DataObject
import com.rightware.kanzi.DataObjectBool
import com.rightware.kanzi.DataObjectInt
import com.rightware.kanzi.DataObjectReal
import com.rightware.kanzi.DataObjectString
import com.rightware.kanzi.DataObjectType
import com.rightware.kanzi.Domain
import com.rightware.kanzi.ObjectRef


/**
 * 将 [BaseData]（XML 解析出的字段描述）实例化为 Kanzi 类型化 [DataObject]。
 *
 * 这是 binding 层最底层的「类型映射」：只负责**单个节点**的创建，不处理树形递归
 * （递归由 [KanziTreeBinder.buildNode] 完成）。
 *
 * | [BaseData.type] | 创建的 Kanzi 类型 |
 * |-----------------|-------------------|
 * | Bool | [DataObjectBool] |
 * | Integer | [DataObjectInt] |
 * | Real | [DataObjectReal] |
 * | String | [DataObjectString] |
 * | List | [DroidDataSource.List]（自定义 DataObjectList） |
 * | 其他 | 普通 [DataObject] 容器 |
 *
 * 列表节点必须使用 [DroidDataSource.List]，这样 Kanzi 渲染列表时会回调
 * `itemCount` / `acquireItem`，最终落到 [com.nextera.droiddatasource.domain.list.ListController]。
 */
class KanziObjectFactory {
    private val tag = KanziObjectFactory::class.java.simpleName

    /**
     * 根据字段类型创建标量 DataObject，并用 XML 默认值或运行时值初始化。
     *
     * @param field SAX 解析得到的 [BaseData]，[BaseData.name] 即 Kanzi 节点名（如 `Int_Test`）
     */
    fun create(domain: Domain, field: BaseData): ObjectRef<out DataObject> = when (field.type) {
        DataObjectType.Bool ->
            DataObjectBool.create(domain, field.name, field.boolValue())
        DataObjectType.Integer ->
            DataObjectInt.create(domain, field.name, field.intValue())
        DataObjectType.Real ->
            DataObjectReal.create(domain, field.name, field.doubleValue())
        DataObjectType.String ->
            DataObjectString.create(domain, field.name, field.stringValue())
        else ->
            DataObject.create(domain, field.name)
    }

    /**
     * 创建列表节点：优先使用插件注册的 [DroidDataSource.List]。
     *
     * 若工厂注册失败（例如 Kanzi Studio 未加载插件类），退化为普通 [DataObject]，
     * 此时列表 UI 将无法通过 DataObjectList 回调拉取数据。
     */
    fun createList(name: String, domain: Domain): DataObject = try {
        DroidDataSource.List.factoryFunction(domain, name).get()
    } catch (e: Exception) {
        PluginLogger.d(tag, "list class can't be created.")
        createPlainObject(domain, name)
    }

    private fun createPlainObject(domain: Domain, name: String): DataObject {
        val ref: ObjectRef<DataObject> = DataObject.create(domain, name)
        return ref.get()
    }
}