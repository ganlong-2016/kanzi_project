package com.nextera.droiddatasource.infrastructure.dispatch

import android.os.Handler
import android.os.Looper
import com.rightware.kanzi.Domain
import com.rightware.kanzi.Platform
import com.rightware.kanzi.TaskDispatcher

/**
 * 在 DataSource 就绪前缓存 Android 侧操作，就绪后在正确线程上执行。
 **/
class TaskQueue(domain: Domain) {

    private val pendingTasks = mutableListOf<() -> Boolean>()
    private val handler: Handler? = if (Platform.isAndroid()) Handler(Looper.getMainLooper()) else null
    private val kanziDispatcher: TaskDispatcher? =
        if (Platform.isAndroid()) null else domain.taskDispatcher

    fun runWhenReady(isReady: () -> Boolean, action: () -> Unit) {
        submit {
            if (isReady()) {
                action()
                true
            } else {
                false
            }
        }
    }

    fun flushPending() {
        dispatch { drainPending() }
    }

    private fun submit(task: () -> Boolean) {
        dispatch {
            if (!task()) {
                pendingTasks.add(task)
            }
        }
    }

    private fun drainPending() {
        val iterator = pendingTasks.iterator()
        while (iterator.hasNext()) {
            iterator.next().invoke()
            iterator.remove()
        }
    }

    private fun dispatch(block: () -> Unit) {
        if (Platform.isAndroid()) {
            handler?.post(block)
        } else {
            kanziDispatcher?.submit(block)
        }
    }
}