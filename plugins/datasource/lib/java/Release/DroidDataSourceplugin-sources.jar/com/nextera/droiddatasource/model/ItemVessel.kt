package com.nextera.droiddatasource.model

/**
 * 列表项模板：每列是一个 [BaseData]，运行时通过 [fillRow] 按列顺序填值。
 */
class ItemVessel {
    private val fields = linkedMapOf<String, BaseData>()

    /**
     * 注册一列；[field.name] 作为列名，同名列不允许重复。
     */
    fun addField(field: BaseData) {
        require(field.name !in fields) {
            "duplicate list column '${field.name}'"
        }
        fields[field.name] = field
    }

    val columns: Collection<BaseData>
        get() = fields.values

    /** 按列插入顺序，用 [values] 依次填充每一列。 */
    fun fillRow(vararg values: Any?) {
        var index = 0
        for (column in fields.values) {
            if (index == values.size) return
            column.applyRuntimeValue(values[index++])
        }
    }

    fun copyTemplate(): ItemVessel = ItemVessel().also { copy ->
        fields.forEach { (name, field) -> copy.fields[name] = field.copy() }
    }
}