package com.nextera.droiddatasource.runtime

import com.nextera.droiddatasource.api.DroidDataSourceClient
import com.nextera.droiddatasource.domain.binding.KanziTreeBinder
import com.nextera.droiddatasource.domain.list.ListController
import com.nextera.droiddatasource.domain.list.ListStore
import com.nextera.droiddatasource.domain.schema.XmlSchemaLoader
import com.nextera.droiddatasource.domain.value.ValueController
import com.nextera.droiddatasource.infrastructure.dispatch.TaskQueue
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.nextera.droiddatasource.infrastructure.resource.ContentProtocolRegistrar
import com.rightware.kanzi.DataSource
import kotlin.text.clear

/**
 * 插件运行时：Kanzi 生命周期、就绪前任务缓存与领域服务聚合。
 *
 * 对「单 DroidDataSource + 单 XML」场景，统一负责：
 * - Kanzi 生命周期（start / onLoaded / stop）
 * - 就绪前任务缓存（Kanzi 未创建 或 XML 未 bind 完成）
 * - schema / binding / list / value 领域服务聚合
 */
internal class PluginEngine {
    private val tag = PluginEngine::class.java.simpleName

    private var kanziDataSource: DataSource? = null
    private var taskQueue: TaskQueue? = null
    private val pendingBeforeStart = mutableListOf<() -> Unit>()

    private val listStore = ListStore()
    private val treeBinder = KanziTreeBinder(listStore)
    private val schemaLoader = XmlSchemaLoader()
    private var valueController: ValueController? = null
    private var listController: ListController? = null

    @Volatile
    var isReady: Boolean = false
        private set

    val activeListController: ListController
        get() = listController ?: error("DroidDataSource is not active")

    fun start(dataSource: DataSource) {
        val existing = kanziDataSource
        when {
            existing === dataSource -> return
            existing != null -> releaseResources()  // Studio 刷新：替换旧实例
        }
        kanziDataSource = dataSource
        taskQueue = TaskQueue(dataSource.domain)
        valueController = ValueController(dataSource)
        listController = ListController(listStore, treeBinder, dataSource.domain)

        ContentProtocolRegistrar.registerIfNeeded(dataSource.domain)
        PluginLogger.d(tag, "start: ${dataSource.name}")

        val queue = taskQueue!!
        val buffered = pendingBeforeStart.toList()
        pendingBeforeStart.clear()
        buffered.forEach { task -> queue.runWhenReady({ isReady }) { task() } }
    }

    fun stop(dataSource: DataSource) {
        val active = kanziDataSource ?: return
        if (active !== dataSource) {
            PluginLogger.d(tag, "ignore stop for unrelated DataSource: ${dataSource.name}")
            return
        }
        releaseResources()
        PluginLogger.d(tag, "stop: ${dataSource.name}")
    }

    private fun releaseResources() {
        isReady = false
        listStore.clear()
        kanziDataSource = null
        taskQueue = null
        valueController = null
        listController = null
        pendingBeforeStart.clear()
    }

    fun onLoaded(xmlPath: String) {
        val dataSource = kanziDataSource
            ?: error("onLoaded called without active DroidDataSource")

        if (xmlPath.isBlank()) {
            PluginLogger.d(tag, "skip schema load: xml path is empty")
            return
        }

        val schema = schemaLoader.load(xmlPath, dataSource)
        treeBinder.bind(schema, dataSource.data)
        markReady(dataSource.name)
    }

    fun setValue(key: String, value: Any?): Boolean =
        valueController?.setValue(key, value) ?: false

    fun notifyListModified(key: String): Boolean =
        valueController?.notifyListModified(key) ?: false

    fun submit(action: () -> Unit) {
        val queue = taskQueue
        if (queue == null) {
            pendingBeforeStart.add(action)
            return
        }
        queue.runWhenReady({ isReady }) { action() }
    }

    private fun markReady(dataSourceName: String) {
        isReady = true
        DroidDataSourceClient.onDataSourceReady()
        taskQueue?.flushPending()
        PluginLogger.d(tag, "ready: $dataSourceName")
    }
}