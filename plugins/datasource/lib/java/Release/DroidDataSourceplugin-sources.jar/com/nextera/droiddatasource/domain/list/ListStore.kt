package com.nextera.droiddatasource.domain.list

import com.nextera.droiddatasource.domain.schema.SchemaDocument
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.nextera.droiddatasource.model.ItemVessel

/**
 * 列表的**内存数据仓库**：保存列定义（模板）与运行时条目。
 *
 * ## 两类数据
 *
 * | 数据 | 来源 | 用途 |
 * |------|------|------|
 * | [templates] | XML 解析 → [com.nextera.droiddatasource.domain.schema.SchemaDocument.listTemplates] | 描述每列类型与默认值，addItems 时克隆 |
 * | [items] | Android `ListHelper.addItems` | 实际列表行数据，Kanzi 渲染时按 index 读取 |
 *
 * ## key 的约定
 *
 * Android API 传入完整路径（如 `DroidDataSource_Test.List_Test`），内部统一转为
 * **短名**（最后一个 `.` 之后，即 `List_Test`），与 Kanzi 节点 [com.rightware.kanzi.DataObject.name] 对齐。
 *
 * ## 与 binding 的分工
 *
 * - **ListStore**：纯 Kotlin 数据，不依赖 Kanzi，负责增删查
 * - **KanziTreeBinder**：把 [ItemVessel] 转成 Kanzi DataObject（在 Kanzi 拉取时调用）
 *
 * 安装时机：[com.nextera.droiddatasource.domain.binding.KanziTreeBinder.bind] 调用 [install]；
 * Session 关闭时 [clear] 释放。
 */
class ListStore {

    private val tag = ListStore::class.java.simpleName

    /** 列表短名 → 列模板，例如 `"List_Test"` → `ItemVessel(index, icon)` */
    private var templates: Map<String, ItemVessel> = emptyMap()

    /** 列表短名 → 已添加的运行时行 */
    private val items = mutableMapOf<String, MutableList<ItemVessel>>()

    /**
     * 从 [SchemaDocument] 加载列表模板，并清空已有运行时数据。
     * 在 XML 重新 bind 时调用。
     */
    fun install(document: SchemaDocument) {
        templates = document.listTemplates
        items.clear()
    }

    fun clear() {
        templates = emptyMap()
        items.clear()
    }

    /** 获取某列表的列模板（无运行时值，仅结构）。 */
    fun templateFor(fullKey: String): ItemVessel? = templates[toShortName(fullKey)]

    /** 获取某列表的运行时行集合；不存在则创建空列表。 */
    fun itemsFor(fullKey: String): MutableList<ItemVessel> {
        val shortName = toShortName(fullKey)
        return items.getOrPut(shortName) { mutableListOf() }
    }

    /**
     * 追加一行列表数据。
     *
     * @param fullKey 完整 DataObject 路径，如 `DroidDataSource_Test.List_Test`
     * @param values 按 XML 列顺序传入的值，个数应与模板列数一致
     *               例如 `addItems(key, "item 0", contentUri)` 对应 `index`、`icon` 两列
     *
     * 内部流程：克隆模板 → [ItemVessel.fillRow] 填值 → 追加到 [items]
     */
    fun addItems(fullKey: String, vararg values: Any?): Boolean {
        val template = templateFor(fullKey) ?: run {
            PluginLogger.d(tag, "itemTemplate of [$fullKey] is null.")
            return false
        }
        itemsFor(fullKey).add(template.copyTemplate().apply { fillRow(*values) })
        return true
    }

    /**
     * 删除列表行。
     *
     * @param index 有效下标时删除单行；否则（如 `-1`）清空该列表全部行
     */
    fun removeItems(fullKey: String, index: Int): Boolean {
        val bucket = itemsFor(fullKey)
        if (index in bucket.indices) {
            bucket.removeAt(index)
        } else {
            bucket.clear()
        }
        return true
    }

    /** `DroidDataSource_Test.List_Test` → `List_Test` */
    private fun toShortName(fullKey: String): String =
        fullKey.substringAfterLast('.', fullKey)
}