package com.nextera.droiddatasource.api

import com.rightware.kanzi.DataObjectType

/**
 * [DroidDataSourceClient.events] 发出的数据源事件。
 *
 * 在协程中收集，例如：
 * ```
 * lifecycleScope.launch {
 *     DroidDataSourceClient.awaitLoaded()
 *     initData()
 * }
 * lifecycleScope.launch {
 *     DroidDataSourceClient.events.collect { event ->
 *         when (event) { ... }
 *     }
 * }
 * ```
 */
sealed class DataSourceEvent {
    /** XML 已解析、Kanzi 数据树已绑定，可安全读写数据。 */
    data object Loaded : DataSourceEvent()

    /** Kanzi [com.nextera.droiddatasource.DroidMessageAction] 转发的事件。 */
    data class Message(
        val key: String,
        val type: DataObjectType,
        val value: String
    ) : DataSourceEvent()
}