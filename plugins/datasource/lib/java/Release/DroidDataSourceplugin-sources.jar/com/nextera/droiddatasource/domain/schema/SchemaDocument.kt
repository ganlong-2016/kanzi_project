package com.nextera.droiddatasource.domain.schema

import com.nextera.droiddatasource.model.BaseData
import com.nextera.droiddatasource.model.ItemVessel
import com.nextera.droiddatasource.model.TreeNode

/**
 * XML 解析结果。
 *
 * - [tree]：整棵数据树，绑定后变成 Kanzi DataObject 层次（含 List 节点）
 * - [listTemplates]：列表短名 → 列定义，例如 `"List_Test"` → `{ index: String, icon: String }`
 */
data class SchemaDocument(
    val tree: TreeNode<BaseData>?,
    val listTemplates: Map<String, ItemVessel> = emptyMap()
)
