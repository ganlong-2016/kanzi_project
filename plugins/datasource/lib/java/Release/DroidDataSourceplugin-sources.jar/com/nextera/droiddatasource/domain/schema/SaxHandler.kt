package com.nextera.droiddatasource.domain.schema

import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.nextera.droiddatasource.model.BaseData
import com.nextera.droiddatasource.model.ItemVessel
import com.nextera.droiddatasource.model.TreeNode
import com.rightware.kanzi.DataObjectType
import com.rightware.kanzi.DataObjectType.List
import com.rightware.kanzi.DataObjectType.Object
import org.xml.sax.Attributes
import org.xml.sax.helpers.DefaultHandler
import java.io.File


/**
 * SAX 流式解析器：把 XML 转成 [SchemaDocument]（Kanzi 数据树 + 列表项模板）。
 *
 * 以 `dataTest.xml` 为例，解析目标分两部分：
 *
 * 1. **数据树**（[treeNode]）：描述 Kanzi 里有哪些节点、各自类型，供 [KanziTreeBinder] 创建 DataObject 树。
 * 2. **列表模板**（[itemTemplates]）：描述 `type="list"` 节点下每一列的字段类型，供运行时 `ListHelper.addItems` 按列填值。
 *
 * ```xml
 * <DroidDataSource_Test>                          <!-- 根容器，无 type → Object -->
 *     <Int_Test type="int">0</Int_Test>          <!-- 标量：进数据树，文本进 characters -->
 *     <List_Test type="list">                     <!-- 列表：进数据树 + 开启列表模板模式 -->
 *         <index type="string">0</index>          <!-- 仅进模板，不进数据树 -->
 *         <icon type="string">0</icon>
 *     </List_Test>
 * </DroidDataSource_Test>
 * ```
 *
 * 解析使用 [nameSpace] 区分当前处于「普通节点」还是「列表模板内部」两种上下文。
 */
internal class SaxHandler(path: String) : DefaultHandler() {
    private val tag = SaxHandler::class.java.simpleName

    val initPath: String = path
    /** Android assets 按文件名打开，例如 `dataTest.xml`。 */
    val fileName: String = path.substringAfterLast(File.separatorChar)

    /** 当前在数据树中的游标；根节点 data 为 null，仅作挂载点。 */
    private var treeNode: TreeNode<BaseData>? = null

    /**
     * 解析上下文：
     * - [DataObjectType.Object]：正在解析普通节点（含根、标量、list 容器本身），`characters` 会读取文本默认值。
     * - [DataObjectType.List]：正在解析某个 `<xxx type="list">` 的内部，子标签只写入 [itemTemplate]，不挂到数据树。
     */
    private var nameSpace: DataObjectType = DataObjectType.Object

    /** `characters` 可能分多次回调，`builderLock` / `builderContent` 用于拼接同一节点的文本。 */
    private var builderLock: String = ""
    private var builderContent: String = ""

    /** 当前正在收集的列表项模板（对应 `<List_Test>` 内的 index、icon 等字段）。 */
    private var itemTemplate: ItemVessel? = null

    /** 列表名 → 列表项模板，例如 `"List_Test"` → ItemVessel(index, icon)。 */
    private var itemTemplates: MutableMap<String, ItemVessel>? = null

    init {
        PluginLogger.d(tag, "new SaxHandler, initPath: $path | fileName: $fileName")
    }

    fun toDocument(): SchemaDocument = SchemaDocument(
        tree = treeNode,
        listTemplates = itemTemplates ?: emptyMap()
    )

    override fun startDocument() {
        treeNode = TreeNode(null)
        nameSpace = DataObjectType.Object
        builderLock = ""
        builderContent = ""
    }

    /**
     * 每遇到一个开始标签调用一次。SAX 按文档顺序深度优先遍历。
     *
     * 对 `dataTest.xml`，典型调用顺序与处理如下：
     *
     * | 标签 | type 属性 | nameSpace 进入前 | 行为 |
     * |------|-----------|------------------|------|
     * | `DroidDataSource_Test` | 无 → Object | Object | 挂到树，游标下移 |
     * | `Int_Test` | int | Object | 挂到树；后续 `characters` 读取 `0` |
     * | `List_Test` | list | Object | 挂到树；创建 ItemVessel；nameSpace→List |
     * | `index` | string | **List** | **只**写入 itemTemplate，**不**挂树（提前 return） |
     * | `icon` | string | List | 同上 |
     */
    override fun startElement(uri: String?, localName: String?, qName: String, attributes: Attributes?) {
        // 读取 type="int" / type="list" 等；无 type 时视为 Object（如根节点 DroidDataSource_Test）
        val typeAttr = attributes?.let { attrs ->
            (0 until attrs.length)
                .firstOrNull { attrs.getQName(it).equals("type", ignoreCase = true) }
                ?.let { attrs.getValue(it) }
        }
        val dataType = TypeConverters.toDataType(typeAttr)
        // 节点名用标签名 qName（如 Int_Test），不是完整路径；Kanzi 侧再通过父节点拼完整 key
        val baseData = BaseData.fromXmlElement(qName, dataType)

        // ── 分支 A：已在 <List_Test type="list"> 内部 ──────────────────────────
        // 此时解析的是列表「列定义」，不是树上一层层嵌套的业务对象。
        // 合法：type 为 int/float/bool/string 的标量标签（如 <index type="string">）
        // 非法：无 type 的节点（→Object）、嵌套 <xxx type="list">
        if (nameSpace == DataObjectType.List) {
            if (dataType != DataObjectType.Object && dataType != DataObjectType.List) {
                // 例：<index type="string"> — 记录「列表每一项有一个 string 字段 index」
                itemTemplate?.addField(baseData)
                return
            }
            throw RuntimeException("list not allow to add list Or object")
        }

        // ── 分支 B：遇到新的 list 容器 ───────────────────────────────────────
        // 例：<List_Test type="list"> — 既要作为树上的 DataObjectList 节点，又要开始收集列模板
        if (dataType == DataObjectType.List) {
            if (itemTemplates == null) itemTemplates = hashMapOf()
            itemTemplate = ItemVessel()
            nameSpace = DataObjectType.List
        }

        // ── 分支 C：普通节点（根、标量、list 容器本身）── 一律挂到数据树并下移游标
        // 例：Int_Test、List_Test、DroidDataSource_Test 都会执行到这里
        val node = TreeNode(baseData)
        treeNode?.addChild(node)
        treeNode = node
    }

    /**
     * 读取标签之间的文本，作为标量字段的 XML 默认值。
     *
     * 仅当 [nameSpace] 为 Object 时生效：
     * - `<Int_Test type="int">0</Int_Test>` → 把 `0` 转成 Int 存进 BaseData
     *
     * 当处于 List 内部（如 `<index type="string">0</index>`）时不处理：
     * - 列表项的实际值由 Android `ListHelper.addItems(...)` 在运行时按列顺序填入
     * - 模板阶段只关心「有哪些列、什么类型」，不关心模板里的占位文本
     */
    override fun characters(ch: CharArray, start: Int, length: Int) {
        if (nameSpace != DataObjectType.Object) return
        val data = treeNode?.data ?: return
        val content = String(ch, start, length).replace("\\s+".toRegex(), "")
        if (builderLock == data.name) {
            data.applyXmlText(builderContent + content)
            builderContent += content
        } else {
            data.applyXmlText(content)
            builderContent = content
        }
        builderLock = data.name
    }

    /**
     * 标签结束：恢复树游标，或在 list 容器结束时保存模板。
     *
     * - 普通节点（nameSpace != List）：游标回退到父节点（如 `</Int_Test>` 回到 DroidDataSource_Test）
     * - list 子标签（如 `</index>`）：qName != List_Test，直接 return，游标仍停在 List_Test
     * - list 容器结束（`</List_Test>`）：把 itemTemplate 存入 itemTemplates，nameSpace 恢复 Object，游标回退
     */
    override fun endElement(uri: String?, localName: String?, qName: String) {
        if (nameSpace != DataObjectType.List) {
            treeNode = treeNode?.parent
            return
        }
        val data = treeNode?.data ?: return
        if (qName != data.name) return
        itemTemplates?.put(qName, itemTemplate!!)
        itemTemplate = null
        nameSpace = DataObjectType.Object
        treeNode = treeNode?.parent
    }

    fun clear() {
        itemTemplate = null
        treeNode = null
    }
}