package com.nextera.droiddatasource.infrastructure.resource

import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.nextera.droiddatasource.infrastructure.resource.ContentLoadTask.Companion.PROTOCOL
import com.rightware.kanzi.Domain
import com.rightware.kanzi.ResourceManager


/**
 * 向 Kanzi [ResourceManager] 注册 `content://` 协议处理器。
 *
 * ## 为什么需要
 *
 * Kanzi 默认只认识 `kzb://` 等引擎内资源。Android 侧要把应用内图片（mipmap/drawable）
 * 显示在 Kanzi UI 上，通常先通过 [com.nextera.droiddatasource.api.DroidDataSourceClient.UriHelper.resToUri]
 * 转成 `content://android.resource/...`，再写入 DataObject（列表 `icon` 字段或 Image 节点 URI）。
 * 若不注册本处理器，Kanzi 遇到 `content://` 时无法加载。
 *
 * ## 执行流程（与 [ContentLoadTask] 配合）
 *
 * ```
 * DataSourceSession.onInitialize()
 *   └─ registerIfNeeded(domain)          // 每个 Domain 只注册一次
 *
 * Android App
 *   └─ UriHelper.resToUri(...)           // R.mipmap.icon → content://android.resource/...
 *   └─ setValue / ListHelper.addItems    // 把 URI 字符串交给 Kanzi
 *
 * Kanzi 渲染需要贴图时
 *   └─ ResourceManager 解析 URL 协议 "content"
 *   └─ 回调本处注册的 handler
 *   └─ 创建 ContentLoadTask 并异步执行 loadFunction → finishFunction
 *   └─ getResult() 返回 Kanzi Texture
 * ```
 *
 * 注册时机：[com.nextera.droiddatasource.runtime.PluginEngine.start]，
 * 在 XML 加载与树绑定之前完成，保证后续任意 `content://` 引用均可被解析。
 */
internal object ContentProtocolRegistrar {

    private val tag = ContentProtocolRegistrar::class.java.simpleName

    fun registerIfNeeded(domain: Domain) {
        if (domain.resourceManager.supportsProtocolHandler(PROTOCOL)) return
        domain.resourceManager.registerProtocolHandler(PROTOCOL) { resourceManager, url, _, hostName, resourcePath ->
            PluginLogger.d(tag, "load content resource: $url")
            ResourceManager.ProtocolHandler.Result(
                ContentLoadTask(resourceManager.domain, url, hostName, resourcePath)
            )
        }
    }
}