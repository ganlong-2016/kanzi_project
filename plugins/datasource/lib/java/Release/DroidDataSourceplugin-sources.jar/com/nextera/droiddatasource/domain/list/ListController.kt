package com.nextera.droiddatasource.domain.list

import com.nextera.droiddatasource.domain.binding.KanziTreeBinder
import com.rightware.kanzi.DataObject
import com.rightware.kanzi.Domain
import com.rightware.kanzi.ObjectRef
import kotlin.collections.get


/**
 * 列表的**双向桥接层**：连接 Android 写操作与 Kanzi [DataObjectList] 读回调。
 *
 * ## 两条数据通路
 *
 * **写（Android → 插件）**
 *
 * ```
 * DroidDataSourceClient.ListHelper.addItems(key, ...)
 *   → PluginEngine.activeListController.addItems
 *   → ListStore.addItems                    // 仅存内存，Kanzi 尚不知情
 *
 * DroidDataSourceClient.ListHelper.update(key)
 *   → ValueController.notifyListModified    // 调用 DataObjectList.notifyModified()
 *   → Kanzi 标记列表脏，触发重新拉取
 * ```
 *
 * **读（Kanzi → 插件）**
 *
 * Kanzi 列表控件渲染时，[com.nextera.droiddatasource.DroidDataSource.List]
 * 作为 DataObjectList 实现，被引擎回调：
 *
 * ```
 * itemCount()        → ListStore 中该列表行数
 * acquireItem(i)     → ListStore 取第 i 行 → KanziTreeBinder.createListItem → DataObject
 * getItemTemplate()→ 用空数据的列模板生成占位结构（Studio 预览 / 布局参考）
 * ```
 *
 * [listName] 参数为 Kanzi 节点短名（如 `List_Test`），与 [ListStore] 内部短名 key 一致。
 */
class ListController(
    private val listStore: ListStore,
    private val treeBinder: KanziTreeBinder,
    private val domain: Domain
) {
    // ── Android 写通路（委托 ListStore）────────────────────────────────────

    fun addItems(fullKey: String, vararg values: Any?): Boolean =
        listStore.addItems(fullKey, *values)

    fun removeItems(fullKey: String, index: Int): Boolean =
        listStore.removeItems(fullKey, index)

    // ── Kanzi 读通路（DataObjectList 回调）──────────────────────────────────

    /** Kanzi 询问列表有多少行。 */
    fun itemCount(listName: String): Int = listStore.itemsFor(listName).size

    /**
     * Kanzi 请求第 [index] 行的 DataObject 子树，用于绑定到列表项 UI。
     * 每次调用即时从 [ItemVessel] 构建，不缓存 Kanzi 侧对象。
     */
    fun acquireItem(listName: String, index: Int): DataObject =
        treeBinder.createListItem(listStore.itemsFor(listName)[index], domain).get()

    /**
     * Kanzi 请求列表项布局模板（无具体数据值）。
     * 用于 Studio 预览或确定子节点结构。
     */
    fun itemTemplate(listName: String): ObjectRef<out DataObject> =
        treeBinder.createListItem(listStore.templateFor(listName), domain)

    /** 列表 DataObject 创建完成；当前无额外初始化逻辑。 */
    @Suppress("UNUSED_PARAMETER")
    fun onListInitialized(listName: String) = Unit

    /** 列表 DataObject 销毁；当前无额外清理逻辑。 */
    @Suppress("UNUSED_PARAMETER")
    fun onListClosed(listName: String) = Unit

    /** Kanzi 回收列表项视图；当前无对象池，无需处理。 */
    @Suppress("UNUSED_PARAMETER")
    fun onItemReleased(listName: String, index: Int) = Unit
}
