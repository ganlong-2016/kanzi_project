package com.nextera.droiddatasource.utils

import com.rightware.kanzi.DataObjectType

/**
 * FileName:     DataSourceUtils
 * Author:       gan long
 * CreateDate:   2026/6/5-11:03
 * Description: 
 **/
object DataSourceUtils {
    fun converDataTypeToObject(type: DataObjectType, value: String?): Any? {
        return when (type) {
            DataObjectType.String -> value
            DataObjectType.Integer -> value?.toInt()
            DataObjectType.Real -> value?.toDouble()
            DataObjectType.Bool -> value?.toBoolean()
            else -> null
        }
    }

    fun convertStringToDataType(typeName: String?) = when (typeName?.lowercase()) {
        "string" -> DataObjectType.String
        "int" -> DataObjectType.Integer
        "double" -> DataObjectType.Real
        "boolean" -> DataObjectType.Bool
        "list" -> DataObjectType.List
        else -> DataObjectType.Object

    }
}