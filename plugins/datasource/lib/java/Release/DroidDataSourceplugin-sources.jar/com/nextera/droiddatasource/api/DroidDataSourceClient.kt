package com.nextera.droiddatasource.api

import android.content.ContentResolver
import android.content.res.Resources
import androidx.core.net.toUri
import com.nextera.droiddatasource.api.DroidDataSourceClient.awaitLoaded
import com.nextera.droiddatasource.api.DroidDataSourceClient.engine
import com.nextera.droiddatasource.api.DroidDataSourceClient.events
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.nextera.droiddatasource.runtime.PluginEngine
import com.rightware.kanzi.DataObjectType
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow


/**
 * Android UI 层唯一入口（单例）。
 *
 * 与 Kanzi 引擎的 [com.rightware.kanzi.DataSource]、适配类
 * [com.nextera.droiddatasource.DroidDataSource] 区分命名，避免导入冲突。
 *
 * 事件通过协程 [events] / [awaitLoaded] 订阅；[engine] 仅供 Kanzi 适配层内部使用。
 */
object DroidDataSourceClient {
    private const val TAG = "DroidDataSourceClient"

    internal val engine = PluginEngine()

    private var xmlPath: String = ""
    private var loggingEnabled: Boolean = false

    private val loadedSignal = CompletableDeferred<Unit>()
    private val _events = MutableSharedFlow<DataSourceEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<DataSourceEvent> = _events.asSharedFlow()

    fun logOpen(open: Boolean) {
        loggingEnabled = open
        PluginLogger.loggingEnabled = open
    }

    fun filePath(path: String) {
        xmlPath = path
    }

    fun setValue(key: String, value: Int) = submitValue(key, value)

    fun setValue(key: String, value: String) = submitValue(key, value)

    fun setValue(key: String, value: Double) = submitValue(key, value)

    fun setValue(key: String, value: Boolean) = submitValue(key, value)

    suspend fun awaitLoaded() {
        loadedSignal.await()
    }

    object ListHelper {
        fun addItems(key: String, vararg item: Any?) =
            submitList(key, "addItems") { engine.activeListController.addItems(key, *item) }

        fun removeItems(key: String, index: Int) =
            submitList(key, "removeItems") { engine.activeListController.removeItems(key, index) }

        fun update(key: String) =
            submitList(key, "update") { engine.notifyListModified(key) }
    }

    object UriHelper {
        fun resToUri(res: Resources, id: Int): String? = try {
            ("${ContentResolver.SCHEME_CONTENT}://" +
                    "${ContentResolver.SCHEME_ANDROID_RESOURCE}/" +
                    "${res.getResourcePackageName(id)}/" +
                    "${res.getResourceTypeName(id)}/" +
                    "${res.getResourceEntryName(id)}").toUri().toString()
        } catch (e: Resources.NotFoundException) {
            PluginLogger.d(TAG, "resource can't be parsed. $e")
            null
        }
    }

    internal fun resolveXmlPath(androidFileProperty: String, studioFileProperty: String): String {
        val path = androidFileProperty.ifBlank {
            xmlPath.ifBlank { studioFileProperty }
        }
        return path.substringAfterLast('/', path).substringAfterLast('\\', path)
    }

    internal fun applyStudioLogging(enabled: Boolean) {
        loggingEnabled = enabled
        PluginLogger.loggingEnabled = enabled
    }

    internal fun onDataSourceReady() {
        if (!loadedSignal.isCompleted) {
            loadedSignal.complete(Unit)
        }
        emit(DataSourceEvent.Loaded)
    }

    internal fun notifyEventChanged(key: String, type: DataObjectType, value: String) {
        emit(DataSourceEvent.Message(key, type, value))
    }

    private fun emit(event: DataSourceEvent) {
        if (!_events.tryEmit(event)) {
            throw IllegalStateException("failed to emit $event: buffer full or no subscribers")
        }
    }

    private fun submitValue(key: String, value: Any) {
        engine.submit {
            if (!engine.setValue(key, value)) {
                PluginLogger.d(TAG, "setValue failed: key=$key value=$value")
            }
        }
    }

    private inline fun submitList(key: String, operation: String, crossinline action: () -> Boolean) {
        engine.submit {
            if (!action()) {
                PluginLogger.d(TAG, "$operation failed: key=$key")
            }
        }
    }
}