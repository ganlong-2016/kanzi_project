package com.nextera.droiddatasource.infrastructure.logging

import com.rightware.kanzi.Log
import com.rightware.kanzi.Platform

/**
 * FileName:     PluginLogger
 * Author:       gan long
 * CreateDate:   2026/6/9-15:40
 * Description: 
 **/
internal object PluginLogger {
    @Volatile
    var loggingEnabled: Boolean = false

    fun d(tag: String, message: String) {
        if (!loggingEnabled) return
        if (Platform.isAndroid()) {
            android.util.Log.d(tag, message)
        } else {
            Log.debug("$tag -- $message")
        }
    }

}