package com.nextera.droiddatasource.domain.value

import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.rightware.kanzi.DataObjectBool
import com.rightware.kanzi.DataObjectInt
import com.rightware.kanzi.DataObjectList
import com.rightware.kanzi.DataObjectReal
import com.rightware.kanzi.DataObjectString
import com.rightware.kanzi.DataSource

/**
 * FileName:     ValueController
 * Author:       gan long
 * CreateDate:   2026/6/9-16:23
 * Description: 
 **/
class ValueController(
    private val dataSource: DataSource
) {
    private val tag = ValueController::class.java.simpleName

    fun setValue(key: String, value: Any?): Boolean {
        if (value == null) return false
        val context = dataSource.data.lookupDataContext(key) ?: return false
        val success = when {
            value is Int && context is DataObjectInt -> {
                context.value = value
                true
            }
            value is Boolean && context is DataObjectBool -> {
                context.value = value
                true
            }
            value is String && context is DataObjectString -> {
                context.value = value
                true
            }
            value is Double && context is DataObjectReal -> {
                context.value = value
                true
            }
            else -> false
        }
        if (!success) {
            PluginLogger.d(tag, "setValue type mismatch: key=$key value=$value")
        }
        return success
    }

    fun notifyListModified(key: String): Boolean {
        val context = dataSource.data.lookupDataContext(key) ?: return false
        if (context !is DataObjectList) return false
        context.notifyModified()
        return true
    }

}