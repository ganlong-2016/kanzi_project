package com.nextera.droiddatasource.infrastructure.resource

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.rightware.kanzi.Domain
import com.rightware.kanzi.ObjectRef
import com.rightware.kanzi.Platform
import com.rightware.kanzi.Resource
import com.rightware.kanzi.ResourceManager
import com.rightware.kanzi.Texture
import androidx.core.net.toUri
import androidx.core.graphics.createBitmap
import com.rightware.kanzi.BitmapImage
import com.rightware.kanzi.GraphicsFormat
import com.rightware.kanzi.TextureBuilder
import java.nio.ByteBuffer
import kotlin.times

/**
 * FileName:     ContentLoadTask
 * Author:       gan long
 * CreateDate:   2026/6/9-15:51
 * Description: 
 **/
class ContentLoadTask (
    private val domain: Domain,
    private val url: String,
    private val hostName: String,
    private val resourcePath: String
): ResourceManager.LoadTask() {

    private var bitmap: Bitmap? = null
    private var texture: ObjectRef<Texture>? = null
    private var name: String = PROTOCOL

    init {
        PluginLogger.d(TAG, "ContentLoadTask: $url - $hostName - $resourcePath")
    }


    /**
     * 阶段一：后台线程解码位图。
     *
     * Kanzi 把 URL 拆成 [hostName]（authority）与 [resourcePath] 传入；
     * 对 `android.resource` 还需结合 [url] 的 path 段解析包名/类型/资源名。
     */
    override fun loadFunction() {
        val context = domain.platformContext as Context
        try {
            if (Platform.isAndroid()){
                val parse = url.toUri()
                val segments = parse.pathSegments
                if (segments.isNotEmpty()) {
                    name = segments.last()
                }
                bitmap =  when{
                    ContentResolver.SCHEME_ANDROID_RESOURCE == hostName -> {
                        val packageName = segments[0]
                        val typeName = segments[1]
                        val resourceName = segments[2]
                        val identifier = context.resources.getIdentifier(resourceName, typeName, packageName)
                        BitmapFactory.decodeResource(context.resources, identifier)
                    }
                    ContentResolver.SCHEME_FILE == hostName -> BitmapFactory.decodeFile(resourcePath)
                    else -> context.contentResolver.openInputStream(url.toUri()).use { stream ->
                        BitmapFactory.decodeStream(stream)
                    }

                }
            }
        }catch (e: Exception){
            bitmap = null
            PluginLogger.d(TAG, "ContentLoadTask can't be loaded: $e")
        }
        ensurePlaceholderBitmap()
    }

    /**
     * 阶段二：Kanzi 线程上将 [Bitmap] 转为 GPU [Texture]。
     *
     * 仅执行一次（[texture] 非空则跳过）。转换后回收 Android 侧 [bitmap] 以释放内存。
     */
    override fun finishFunction() {
        ensurePlaceholderBitmap()
        if (texture != null) return

        val currentBitmap = bitmap ?: return
        // Y 轴翻转
        // Android Bitmap：原点在左上角，Y 向下
        // OpenGL / Kanzi 纹理：常用原点在左下角，Y 向上
        val flipped = BitmapUtils.flip(currentBitmap)
        // Android 像素顺序：A R G B（在一个 32 位 int 里）
        // OpenGL / Kanzi 像素顺序：R G B A
        val rgba = BitmapUtils.swizzleARGBToRGBA(BitmapUtils.bitmapToPixelArray(flipped))
        val byteBuffer = ByteBuffer.allocate(rgba.size * 4)
        byteBuffer.asIntBuffer().put(rgba)

        val format = GraphicsFormat.GraphicsFormatR8G8B8A8_UNORM
        try {
            BitmapImage(
                flipped.width,
                flipped.height,
                format,
                byteBuffer.array(),
                name
            ).use { image ->
                texture = TextureBuilder()
                    .setName(name)
                    .setWidth(flipped.width.toLong())
                    .setHeight(flipped.height.toLong())
                    .setImages(arrayOf(image))
                    .setFormat(format)
                    .build(domain)
                flipped.recycle()
                bitmap = null
            }
        } catch (e: Exception) {
            PluginLogger.d(TAG, "BitmapImage can't be created. $e")
        }
    }

    /** 将构建好的贴图交给 Kanzi ResourceManager（克隆引用，避免所有权冲突）。 */
    override fun getResult(): ObjectRef<out Resource> = texture!!.clone()

    /** 解码失败时提供透明占位，保证 [finishFunction] / [getResult] 仍可继续。 */
    private fun ensurePlaceholderBitmap() {
        if (bitmap == null && texture == null) {
            bitmap = createBitmap(64, 64).also { bmp ->
                Canvas(bmp).drawColor(0x00000000)
            }
        }
    }

    companion object {
        private const val TAG = "ContentLoadTask"
        /** 与 [ContentProtocolRegistrar] 注册到 ResourceManager 的协议名一致（对应 `content://`）。 */
        const val PROTOCOL = "content"
    }
}