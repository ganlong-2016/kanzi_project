package com.nextera.droiddatasource

import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.rightware.kanzi.MetaclassRegistry
import com.rightware.kanzi.Plugin

/**
 * FileName:     DroidDataSourcePlugin
 * Author:       gan long
 * CreateDate:   2026/6/10-14:17
 * Description: 
 **/
class DroidDataSourcePlugin : Plugin() {
    override fun getName(): String {
        PluginLogger.d(DroidDataSourcePlugin::class.java.simpleName, BuildConfig.PLUGIN_VERSION)
        return BuildConfig.PLUGIN_NAME
    }

    override fun registerClasses(metaclassRegistry: MetaclassRegistry) {
        metaclassRegistry.registerClass(DroidDataSource::class.java)
        metaclassRegistry.registerClass(DroidDataSource.List::class.java)
        metaclassRegistry.registerClass(DroidMessageAction::class.java)
    }
}
