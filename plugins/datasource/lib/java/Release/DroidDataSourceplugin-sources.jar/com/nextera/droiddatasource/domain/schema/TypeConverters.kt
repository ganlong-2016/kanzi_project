package com.nextera.droiddatasource.domain.schema

import com.rightware.kanzi.DataObjectType
import com.rightware.kanzi.DataObjectType.Object
import com.rightware.kanzi.DataObjectType.String

/**
 * XML `type` 属性与 Kanzi [DataObjectType] 的映射，以及标签文本到运行时值的转换。
 *
 * `type` 缺省或为未知值时视为 [DataObjectType.Object]（用于无 type 的根节点）；
 * `string` 与 `String` 均识别为 [DataObjectType.String]（兼容大小写）。
 */
internal object TypeConverters {

    /** 解析开始标签上的 `type="int"` 等属性。 */
    fun toDataType(typeName: String?): DataObjectType = when {
        typeName.equals("int", ignoreCase = true) -> DataObjectType.Integer
        typeName.equals("float", ignoreCase = true) -> DataObjectType.Real
        typeName.equals("bool", ignoreCase = true) -> DataObjectType.Bool
        typeName.equals("String", ignoreCase = true) -> DataObjectType.String
        typeName.equals("list", ignoreCase = true) -> DataObjectType.List
        else -> DataObjectType.Object
    }

    /** 解析标量标签体内的文本，例如 `<Int_Test type="int">0</Int_Test>` 中的 `0`。 */
    fun toValue(type: DataObjectType, raw: String?): Any? = when (type) {
        DataObjectType.Real -> {
            val normalized = raw?.replace("\\s+".toRegex(), "")
            if (normalized == null) 0.0 else normalized.toDoubleOrNull() ?: 0.0
        }
        DataObjectType.Bool -> {
            val normalized = raw?.replace("\\s+".toRegex(), "")
            if (normalized == null) {
                false
            } else {
                normalized.equals("true", ignoreCase = true) || normalized == "1"
            }
        }
        DataObjectType.Integer -> {
            val normalized = raw?.replace("\\s+".toRegex(), "")
            if (normalized == null) 0 else normalized.toIntOrNull() ?: 0
        }
        DataObjectType.String -> raw ?: ""
        else -> null
    }
}