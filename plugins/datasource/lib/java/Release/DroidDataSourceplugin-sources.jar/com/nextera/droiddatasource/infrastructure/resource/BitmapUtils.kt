package com.nextera.droiddatasource.infrastructure.resource

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PaintFlagsDrawFilter
import android.graphics.Rect
import android.graphics.drawable.Drawable
import androidx.core.graphics.createBitmap

/**
 * FileName:     BitmapUtils
 * Author:       gan long
 * CreateDate:   2026/6/9-15:41
 * Description: 
 **/
internal object BitmapUtils {
    fun drawableToBitmap(drawable: Drawable, width: Int, height: Int): Bitmap? = try {
        createBitmap(width, height).also { bmp ->
            val canvas = Canvas(bmp)
            canvas.drawFilter = PaintFlagsDrawFilter(Paint.DITHER_FLAG, Paint.FILTER_BITMAP_FLAG)
            drawable.setBounds(Rect(0, 0, width, height))
            drawable.draw(canvas)
        }
    } catch (_: OutOfMemoryError) {
        null
    }

    fun getDrawableForDensity(id: Int, resources: Resources, density: Int): Drawable? = try {
        resources.getDrawableForDensity(id, density, null)
    } catch (_: Exception) {
        null
    }

    fun bitmapToPixelArray(bitmap: Bitmap): IntArray {
        val size = bitmap.width * bitmap.height
        val pixels = IntArray(size)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        return pixels
    }

    fun swizzleABGRToRGBA(pixels: IntArray): IntArray {
        for (i in pixels.indices) {
            val pixel = pixels[i]
            val a = (pixel shr 24) and 0xff
            val b = (pixel shr 16) and 0xff
            val g = (pixel shr 8) and 0xff
            val r = pixel and 0xff
            pixels[i] = ((r and 0xff) shl 24) or ((g and 0xff) shl 16) or ((b and 0xff) shl 8) or (a and 0xff)
        }
        return pixels
    }

    fun swizzleARGBToRGBA(pixels: IntArray): IntArray {
        for (i in pixels.indices) {
            val pixel = pixels[i]
            val a = (pixel shr 24) and 0xff
            val r = (pixel shr 16) and 0xff
            val g = (pixel shr 8) and 0xff
            val b = pixel and 0xff
            pixels[i] = ((r and 0xff) shl 24) or ((g and 0xff) shl 16) or ((b and 0xff) shl 8) or (a and 0xff)
        }
        return pixels
    }

    fun rotateBitmap(source: Bitmap, angle: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(angle) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    fun flip(source: Bitmap): Bitmap {
        val scaleMatrix = Matrix().apply { preScale(1f, -1f) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, scaleMatrix, false)
    }
}