package com.nextera.droiddatasource

import com.nextera.droiddatasource.api.DroidDataSourceClient
import com.nextera.droiddatasource.infrastructure.logging.PluginLogger
import com.rightware.kanzi.DataObjectType
import com.rightware.kanzi.Domain
import com.rightware.kanzi.EditorInfo
import com.rightware.kanzi.ForwardingAction
import com.rightware.kanzi.Metaclass
import com.rightware.kanzi.Metadata
import com.rightware.kanzi.ObjectRef
import com.rightware.kanzi.PropertyType


/** Kanzi → Android 消息动作，事件转发到 [DroidDataSourceClient] 已注册的监听器。 */
class DroidMessageAction private constructor(
    domain: Domain,
    nativeNode: Long,
    metaclass: Metaclass
) : ForwardingAction(domain, nativeNode, metaclass) {

    companion object {
        private const val TAG = "DroidMessageAction"

        @JvmField
        @Metadata
        val metaclass = Metaclass("DroidMessageAction")

        @JvmStatic
        fun create(domain: Domain, name: String): ObjectRef<DroidMessageAction> =
            createDerived(domain, name, metaclass)
    }

    @Metadata
    class ForwardArguments {
        companion object {
            @JvmField
            @Metadata
            val sStaticMetaclass = Metaclass("DroidMessageAction.ForwardArguments")

            @JvmField
            @Metadata
            @EditorInfo(displayName = "Massage Key")
            val MessageKey = PropertyType<String>("Key", String::class.java)

            @JvmField
            @Metadata
            @EditorInfo(
                displayName = "Message Type",
                valueProvider = "Enum:Integer|1;Double|2;Boolean|3;String|4"
            )
            val MessageType = PropertyType<Int>("Type", Int::class.javaObjectType)

            @JvmField
            @Metadata
            @EditorInfo(displayName = "Massage Value")
            val MessageValue = PropertyType<String>("Value", String::class.java)
        }
    }

    override fun onInvoke() {
        super.onInvoke()
        val key = getArgument(ForwardArguments.MessageKey)
        val type = DataObjectType.values()[getArgument(ForwardArguments.MessageType)]
        val value = getArgument(ForwardArguments.MessageValue)

        DroidDataSourceClient.notifyEventChanged(key, type, value)
        PluginLogger.d(TAG, "Key: $key, value: $value, type: ${type.name}")
    }
}