package com.nextera.droiddatasource.model

import com.nextera.droiddatasource.domain.schema.TypeConverters
import com.rightware.kanzi.DataObjectType

/**
 * FileName:     BaseData
 * Author:       gan long
 * CreateDate:   2026/6/5-10:58
 * Description: 
 **/

data class BaseData(
    val name: String,
    val type: DataObjectType,
    var value: Any?,
) {


    companion object {
        /** 遇到 XML 开始标签时创建；标量类型会带上 [TypeConverters] 的默认值。 */
        fun fromXmlElement(tagName: String, type: DataObjectType): BaseData =
            BaseData(tagName, type, TypeConverters.toValue(type, null))
    }

    /** SAX [characters] 回调：把标签内文本解析为 [type] 对应的值。 */
    fun applyXmlText(raw: String?) {
        value = TypeConverters.toValue(type, raw)
    }

    /** 运行时赋值；`null` 表示跳过（保留 XML 默认或已有值）。 */
    fun applyRuntimeValue(runtimeValue: Any?) {
        if (runtimeValue != null) {
            value = runtimeValue
        }
    }

    fun boolValue(): Boolean = valueOf(Boolean::class.java)

    fun intValue(): Int = valueOf(Int::class.java)

    fun doubleValue(): Double = valueOf(Double::class.java)

    fun stringValue(): String = valueOf(String::class.java)

    @Suppress("UNCHECKED_CAST")
    private fun <T> valueOf(clazz: Class<T>): T {
        val current = value
        if (clazz.isInstance(current)) {
            return clazz.cast(current)
        }
        val resolved = resolvePrimitive(clazz)
            ?: throw IllegalArgumentException(
                "Value type mismatch for ${clazz.simpleName}, " +
                        "field=$name, actual=${current?.javaClass?.simpleName}"
            )
        return resolved as T
    }

    /**
     * XML 解析后 [value] 常为 Java 装箱类型（如 [java.lang.Boolean]），
     * Kanzi API 侧使用原始类型 [Class]（如 [Boolean.TYPE]）。
     */
    private fun resolvePrimitive(clazz: Class<*>): Any? {
        val current = value
        return when (clazz) {
            java.lang.Boolean.TYPE, java.lang.Boolean::class.java -> when (current) {
                is Boolean -> current
                is java.lang.Boolean -> current.booleanValue()
                else -> null
            }
            java.lang.Integer.TYPE, java.lang.Integer::class.java -> when (current) {
                is Int -> current
                is Integer -> current.toInt()
                else -> null
            }
            java.lang.Double.TYPE, java.lang.Double::class.java -> when (current) {
                is Double -> current
                is java.lang.Double -> current.toDouble()
                else -> null
            }
            else -> null
        }
    }
}
